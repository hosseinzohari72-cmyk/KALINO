package com.kalino.wholesale;

import android.app.*;import android.os.*;import android.graphics.Color;import android.graphics.drawable.GradientDrawable;import android.view.*;import android.view.inputmethod.InputMethodManager;import android.content.*;import android.widget.*;import java.text.NumberFormat;import java.util.*;

public class MainActivity extends Activity {
  LinearLayout root, content, grid; EditText search; TextView cartBadge; int cartCount=0, total=0; final int GREEN=Color.rgb(13,139,91); final int BG=Color.rgb(247,248,250);
  String[] names={"رب گوجه فرنگی","نوشابه خانواده","تن ماهی","چیپس نمکی","دستمال کاغذی","ماکارونی"};
  String[] cats={"کنسرو و رب","نوشیدنی","کنسرو و رب","تنقلات","بهداشت","خشکبار"};
  int[] prices={420000,510000,1850000,690000,880000,620000}; String[] emoji={"🍅","🥤","🥫","🥔","🧻","🍝"};
  @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(Color.WHITE);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR); build(); showHome();}
  TextView tv(String s,float sp,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(color);t.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);t.setPadding(8,4,8,4);return t;}
  GradientDrawable bg(int color,float r){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(r);return g;}
  LinearLayout box(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);return l;}
  void build(){
    root=box();root.setBackgroundColor(BG);setContentView(root);
    LinearLayout top=box();top.setPadding(18,12,18,8);top.setBackgroundColor(Color.WHITE);top.setOrientation(LinearLayout.HORIZONTAL);top.setGravity(Gravity.CENTER_VERTICAL);
    TextView title=tv("کالینو",25,Color.rgb(23,32,28));title.setTypeface(null,1);top.addView(title,new LinearLayout.LayoutParams(0,58,1));
    TextView store=tv("▣",26,GREEN);store.setGravity(Gravity.CENTER);top.addView(store,new LinearLayout.LayoutParams(58,58));root.addView(top);
    content=box();root.addView(content,new LinearLayout.LayoutParams(-1,0,1));
    LinearLayout nav=box();nav.setOrientation(LinearLayout.HORIZONTAL);nav.setGravity(Gravity.CENTER);nav.setPadding(8,5,8,5);nav.setBackgroundColor(Color.WHITE);
    nav.addView(navBtn("خانه", "⌂", true, v->showHome()),new LinearLayout.LayoutParams(0,64,1));nav.addView(navBtn("سفارش‌ها","▤",false,v->showOrders()),new LinearLayout.LayoutParams(0,64,1));nav.addView(navBtn("حساب من","◉",false,v->showProfile()),new LinearLayout.LayoutParams(0,64,1));root.addView(nav);
  }
  TextView navBtn(String a,String i,boolean on,View.OnClickListener c){TextView t=tv(i+"\n"+a,12,on?GREEN:Color.DKGRAY);t.setGravity(Gravity.CENTER);t.setOnClickListener(c);return t;}
  void showHome(){content.removeAllViews();
    search=new EditText(this);search.setHint("جستجوی کالا، برند یا دسته‌بندی...");search.setSingleLine();search.setTextSize(14);search.setPadding(18,0,18,0);search.setBackground(bg(Color.WHITE,40));content.addView(search,new LinearLayout.LayoutParams(-1,54));
    LinearLayout.LayoutParams m=new LinearLayout.LayoutParams(-1,145);m.setMargins(0,14,0,10);TextView banner=tv("خرید عمده، راحت‌تر از همیشه\nقیمت همکاری برای فروشگاه‌ها\nارسال سفارش از انبار کالینو                 🛒",18,Color.WHITE);banner.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);banner.setPadding(20,10,20,10);banner.setBackground(bg(GREEN,28));content.addView(banner,m);
    TextView ct=tv("دسته‌بندی‌ها",18,Color.rgb(23,32,28));ct.setTypeface(null,1);content.addView(ct,new LinearLayout.LayoutParams(-1,45));
    HorizontalScrollView hs=new HorizontalScrollView(this);LinearLayout catsL=new LinearLayout(this);catsL.setOrientation(LinearLayout.HORIZONTAL);String[] c={"همه","نوشیدنی","تنقلات","کنسرو و رب","خشکبار","بهداشت"};for(String x:c){TextView z=tv("◉\n"+x,11,GREEN);z.setGravity(Gravity.CENTER);z.setBackground(bg(Color.WHITE,60));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(75,78);p.setMargins(5,0,5,8);catsL.addView(z,p);}hs.addView(catsL);content.addView(hs,new LinearLayout.LayoutParams(-1,88));
    LinearLayout row=box();row.setOrientation(LinearLayout.HORIZONTAL);TextView d=tv("تخفیف‌های امروز",18,Color.rgb(23,32,28));d.setTypeface(null,1);row.addView(d,new LinearLayout.LayoutParams(0,48,1));TextView all=tv("۶ کالا",13,Color.GRAY);all.setGravity(Gravity.CENTER_VERTICAL|Gravity.LEFT);row.addView(all,new LinearLayout.LayoutParams(60,48));content.addView(row);
    ScrollView sv=new ScrollView(this);grid=new LinearLayout(this);grid.setOrientation(LinearLayout.VERTICAL);for(int r=0;r<3;r++){LinearLayout rr=new LinearLayout(this);rr.setOrientation(LinearLayout.HORIZONTAL);for(int cidx=0;cidx<2;cidx++){int i=r*2+cidx;if(i<6)rr.addView(card(i),new LinearLayout.LayoutParams(0,230,1));}grid.addView(rr);}sv.addView(grid);content.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
    search.setOnEditorActionListener((v,a,e)->{filter(search.getText().toString());return true;});
  }
  View card(int i){LinearLayout card=box();card.setPadding(10,8,10,8);card.setBackground(bg(Color.WHITE,22));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,220,1);p.setMargins(5,5,5,5);card.setLayoutParams(p);TextView pic=tv(emoji[i],45,Color.DKGRAY);pic.setGravity(Gravity.CENTER);card.addView(pic,new LinearLayout.LayoutParams(-1,75));TextView n=tv(names[i],14,Color.rgb(23,32,28));n.setTypeface(null,1);card.addView(n,new LinearLayout.LayoutParams(-1,32));card.addView(tv("کارتن عمده",11,Color.GRAY),new LinearLayout.LayoutParams(-1,24));LinearLayout rr=new LinearLayout(this);rr.setOrientation(LinearLayout.HORIZONTAL);TextView pr=tv(money(prices[i]),12,Color.rgb(23,32,28));pr.setTypeface(null,1);rr.addView(pr,new LinearLayout.LayoutParams(0,48,1));Button add=new Button(this);add.setText("+");add.setTextColor(Color.WHITE);add.setBackground(bg(GREEN,18));add.setOnClickListener(v->{cartCount++;total+=prices[i];Toast.makeText(this,"به سبد اضافه شد",Toast.LENGTH_SHORT).show();});rr.addView(add,new LinearLayout.LayoutParams(55,48));card.addView(rr);return card;}
  void filter(String q){if(q.trim().isEmpty()){showHome();return;}Toast.makeText(this,"جستجو: "+q,Toast.LENGTH_SHORT).show();}
  String money(int n){return NumberFormat.getInstance(Locale.US).format(n)+" تومان";}
  void showOrders(){content.removeAllViews();TextView t=tv("سفارش‌های من",22,Color.rgb(23,32,28));t.setTypeface(null,1);content.addView(t,new LinearLayout.LayoutParams(-1,70));TextView e=tv("▤\n\nهنوز سفارشی ثبت نشده\nاولین سفارش عمده خود را ثبت کنید",18,Color.GRAY);e.setGravity(Gravity.CENTER);content.addView(e,new LinearLayout.LayoutParams(-1,0,1));}
  void showProfile(){content.removeAllViews();TextView t=tv("حساب فروشگاه",22,Color.rgb(23,32,28));t.setTypeface(null,1);content.addView(t,new LinearLayout.LayoutParams(-1,70));String[] x={"اطلاعات فروشگاه","آدرس و تحویل سفارش","روش‌های پرداخت","پشتیبانی کالینو"};for(String s:x){TextView q=tv(s+"                                      ›",16,Color.DKGRAY);q.setBackground(bg(Color.WHITE,18));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,60);p.setMargins(0,5,0,5);content.addView(q,p);}}
}
