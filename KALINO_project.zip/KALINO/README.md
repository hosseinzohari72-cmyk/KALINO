# KALINO

اپ فروش عمده‌فروشی کالینو با رابط فارسی و راست‌به‌چپ.

## ساخت APK
این پروژه برای Codemagic آماده شده است. Codemagic قبل از build فایل‌های استاندارد Android پروژه Flutter را با `flutter create .` می‌سازد و سپس APK نسخه release را تولید می‌کند.

## فایل اصلی
`lib/main.dart`
