import 'package:flutter/material.dart';

void main() {
  runApp(const KalinoApp());
}

class KalinoApp extends StatelessWidget {
  const KalinoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'کالینو',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'sans',
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF0B8F55)),
        scaffoldBackgroundColor: const Color(0xFFF7F8FA),
      ),
      home: const Directionality(
        textDirection: TextDirection.rtl,
        child: HomePage(),
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;
  final search = TextEditingController();

  final categories = const [
    ('نوشیدنی', Icons.local_drink_outlined),
    ('تنقلات', Icons.cookie_outlined),
    ('کنسرو', Icons.inventory_2_outlined),
    ('لبنیات', Icons.icecream_outlined),
    ('شوینده', Icons.cleaning_services_outlined),
    ('بهداشتی', Icons.health_and_safety_outlined),
  ];

  final products = const [
    ('نوشابه خانواده', 'پک ۶ عددی', '۲۸۵٬۰۰۰ تومان', Icons.local_drink),
    ('چیپس نمکی', 'پک ۱۲ عددی', '۳۶۰٬۰۰۰ تومان', Icons.fastfood),
    ('رب گوجه', 'کارتن ۱۲ عددی', '۵۴۰٬۰۰۰ تومان', Icons.inventory),
    ('مایع ظرفشویی', 'کارتن ۴ عددی', '۴۸۰٬۰۰۰ تومان', Icons.cleaning_services),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: const Text('کالینو', style: TextStyle(fontWeight: FontWeight.w900)),
        actions: [
          IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none)),
          IconButton(onPressed: () {}, icon: const Icon(Icons.shopping_cart_outlined)),
        ],
      ),
      body: tab == 0 ? _home() : _placeholder(),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'خانه'),
          NavigationDestination(icon: Icon(Icons.category_outlined), label: 'دسته‌ها'),
          NavigationDestination(icon: Icon(Icons.receipt_long_outlined), label: 'سفارش‌ها'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'حساب من'),
        ],
      ),
    );
  }

  Widget _home() {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 20),
      children: [
        TextField(
          controller: search,
          decoration: InputDecoration(
            hintText: 'جستجوی کالا، برند یا دسته‌بندی...',
            prefixIcon: const Icon(Icons.search),
            filled: true,
            fillColor: Colors.white,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: BorderSide.none,
            ),
          ),
        ),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            gradient: const LinearGradient(
              colors: [Color(0xFF087F4C), Color(0xFF16A66A)],
            ),
          ),
          child: const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('خرید عمده، ساده و سریع',
                  style: TextStyle(color: Colors.white, fontSize: 23, fontWeight: FontWeight.w900)),
              SizedBox(height: 8),
              Text('قیمت همکاری + ارسال به فروشگاه شما',
                  style: TextStyle(color: Colors.white70, fontSize: 14)),
              SizedBox(height: 18),
              Text('پیشنهادهای ویژه امروز ←',
                  style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            ],
          ),
        ),
        const SizedBox(height: 20),
        const Text('دسته‌بندی‌ها', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
        const SizedBox(height: 12),
        SizedBox(
          height: 100,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: categories.length,
            separatorBuilder: (_, __) => const SizedBox(width: 12),
            itemBuilder: (_, i) => SizedBox(
              width: 78,
              child: Column(
                children: [
                  CircleAvatar(
                    radius: 30,
                    backgroundColor: const Color(0xFFE3F4EC),
                    child: Icon(categories[i].$2, color: const Color(0xFF087F4C)),
                  ),
                  const SizedBox(height: 7),
                  Text(categories[i].$1, style: const TextStyle(fontSize: 12), overflow: TextOverflow.ellipsis),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(height: 10),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text('پرفروش‌های امروز', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
            TextButton(onPressed: () {}, child: const Text('مشاهده همه')),
          ],
        ),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: products.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
            childAspectRatio: .78,
          ),
          itemBuilder: (_, i) {
            final p = products[i];
            return Card(
              color: Colors.white,
              elevation: 0,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Container(
                        width: double.infinity,
                        decoration: BoxDecoration(
                          color: const Color(0xFFF1F3F5),
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: Icon(p.$4, size: 58, color: const Color(0xFF087F4C)),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(p.$1, style: const TextStyle(fontWeight: FontWeight.w800)),
                    const SizedBox(height: 4),
                    Text(p.$2, style: const TextStyle(color: Colors.grey, fontSize: 12)),
                    const SizedBox(height: 7),
                    Text(p.$3, style: const TextStyle(fontWeight: FontWeight.w900)),
                    const SizedBox(height: 7),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton.icon(
                        onPressed: () {},
                        icon: const Icon(Icons.add_shopping_cart, size: 17),
                        label: const Text('افزودن'),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ],
    );
  }

  Widget _placeholder() {
    final titles = ['دسته‌بندی‌ها', 'سفارش‌های من', 'حساب کاربری'];
    return Center(
      child: Text(titles[tab - 1], style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
    );
  }
}
